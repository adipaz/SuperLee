GROUP G
206368722 Tali Malenboim
211905641 Ravid Rom
322572926 Benny Skidanov
315198796 Matan Hazan
322217472 Omer Kempner
211993142 Adi Paz
208084004 Inon Katz
318773439 Sean Pikulin 